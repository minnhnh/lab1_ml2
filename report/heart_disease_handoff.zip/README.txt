Heart Disease handoff for Nguyễn Hoàng Minh

Start with report/heart_disease_section.md and place it in the combined report. Its three images are in report/figures/ and the detailed CSV evidence is in report/tables/. The reproducible analysis is notebooks/02_heart_disease.ipynb.

The raw UCI data file is intentionally excluded. Figure captions HD-1 to HD-3 should be renumbered when the team assembles the final report.
